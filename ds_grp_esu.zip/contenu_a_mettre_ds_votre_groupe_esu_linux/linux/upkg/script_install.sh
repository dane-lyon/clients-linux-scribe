#!/bin/bash

## Indiquer ici ce que vous voulez installer, exemple pour VLC (sans le # au début évidemment !)

sudo apt install gnome-mpv -y


